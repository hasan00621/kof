## About

KOF is a cheat program for the Knight Online. aka Koxp

The reason I created this project was to understand how to cheat in online games.

I previously developed this project in Visual Basic .NET, but due to some technical limitations I modernized it with C#

If you want to look at the old project [trkyshorty/KOF-VB.Net](https://github.com/trkyshorty/KOF-VB.Net)

## Notes

Please use Dev branch for contribution

## Installation

Copy **Migration and Resource** folders to Output Directory (Bin/Debug or Bin/Release)

## Live Test

[Download KOF](https://download.kofbot.com/updates/KOF.exe)

## Discord

[If you need help for KOF](https://discord.gg/GaAYYzKs5k)

## Tested Servers (29-02-2022)

- JPKO
- CNKO
- Some Private Servers (NO-AC)

## Screenshots

![KOF Main](https://www.imagevisit.com/images/2021/12/30/18cc36fea12c64553.md.png)

## Special Thanks
[Mustafa Kemal GILOR](https://github.com/mustafakemalgilor)

[Can Sayan](https://github.com/dcansyn)
