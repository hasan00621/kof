﻿namespace KOF.Common
{
    public class Party
    {
        public int MemberId { get; set; }
        public string MemberName { get; set; }
        public int MemberClass { get; set; }
        public int MemberHp { get; set; }
        public int MemberMaxHp { get; set; }
        public int MemberBuffHp { get; set; }
        public int MemberBuffTime { get; set; }
        public int MemberCure1 { get; set; }
        public int MemberCure2 { get; set; }
        public int MemberCure3 { get; set; }
        public int MemberCure4 { get; set; }
        public int MemberResistTime { get; set; }


    }
}
