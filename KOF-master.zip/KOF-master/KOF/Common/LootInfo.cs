﻿namespace KOF.Common
{
    public class LootInfo
    {
        public string Id { get; set; }
        public int MobId { get; set; }
        public int DropTime { get; set; }
        public int X { get; set; }
        public int Y { get; set; }


    }
}
