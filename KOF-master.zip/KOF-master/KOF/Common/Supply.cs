﻿using KOF.Models;

namespace KOF.Common
{
    public class Supply
    {
        public Item Item { get; set; }
        public int Count { get; set; }
        public Npc Npc { get; set; }
    }
}
