﻿UPDATE "account" SET "platform" = 'JPKO';
UPDATE "control" SET "platform" = 'JPKO';
UPDATE "loot" SET "platform" = 'JPKO';
UPDATE "npc" SET "platform" = 'JPKO';
UPDATE "sell" SET "platform" = 'JPKO';
UPDATE "skillbar" SET "platform" = 'JPKO';