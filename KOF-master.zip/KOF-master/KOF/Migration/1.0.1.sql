﻿INSERT INTO "npc" ("realid", "zone", "type", "x", "y", "town", "nation") VALUES (18749, 73, 'Inn', 500, 114, 1, 1);
INSERT INTO "npc" ("realid", "zone", "type", "x", "y", "town", "nation") VALUES (18750, 73, 'Sunderies', 516, 100, 1, 1);
INSERT INTO "npc" ("realid", "zone", "type", "x", "y", "town", "nation") VALUES (18740, 73, 'Inn', 524, 904, 1, 2);
INSERT INTO "npc" ("realid", "zone", "type", "x", "y", "town", "nation") VALUES (18741, 73, 'Sunderies', 509, 914, 1, 2);